(* ::Package:: *)

(* :Title: BestExample *)


(* :Context: ProgrammingInMathematica`BestExample` *)
(* :Author: Maeder *)
(* :Summary:     an example of good programming style *)
(* :Copyright:  *)
(* :Package Version *)
(* :Mathematica Version *)
(* :History:  *)
(* :Keywords: programming style, local variables *)
(* :Sources:  biblio  *)
(* :Discussion:  *)

PowerSum::usage = "PowerSum[x, n] returns the sum of the first n powers of x."

Begin["Private`"]

PowerSum[x_, n_] :=
    Module[{i},
    	Sum[ x^i, {i, 1, n} ]
    ]

End[]
