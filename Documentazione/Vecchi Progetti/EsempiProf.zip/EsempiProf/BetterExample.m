(* ::Package:: *)

(* :Title: BetterExample *)


(* :Context: ProgrammingInMathematica`BetterExample` *)
(* :Author:  Maeder *)
(* :Summary:     an example of good programming style.  *)
(* :Copyright:  *)
(* :Package Version *)
(* :Mathematica Version *)
(* :History:  *)
(* :Keywords: template, skeleton, package *)
(* :Sources:  biblio  *)
(* :Discussion:  *)

(*  ATTENZIONE :  i  simboli ausliari  i, n, x  sono  visibili  nel  contesto  Globale  *)

PowerSum::usage = "PowerSum[x, n] returns the sum of the first n powers of x."

PowerSum[x_, n_] :=
    Module[{i},
    	Sum[ x^i, {i, 1, n} ]
    ]
