(* ::Package:: *)

(* :Title: ComplexMap0 *)


(* :Context: ComplexMap0` *)

(* :Author: Roman E. Maeder *)

(* :Summary:
   a prelimiary version of the ComplexMap package
 *)

(* :Copyright:  Maeder *)

(* :Package Version:  *)

(* :Mathematica Version: *)

(* :History:  *)

(* :Sources:  biblio   *)

(* :Limitations:
   this is a preliminary version, for educational purposes only.
   The final code is in ProgrammingInMathematica/ComplexMap.m   *)

(* :Discussion:   *)

BeginPackage["ComplexMap`"]

CartesianMap::usage =
	"CartesianMap[f, {x0, x1, dx}, {y0, y1, dy}] plots the image
	of the Cartesian coordinate lines under the function f."

PolarMap::usage =
	"PolarMap[f, {r0, r1, dr}, {p0, p1, dp}] plots the image
	of the polar coordinate lines under the function f."

Begin["`Private`"]

CartesianMap[ func_, {x0_, x1_, dx_}, {y0_, y1_, dy_} ] :=
    Module[ {x, y},
        Picture[ func[x + I y], {x, x0, x1, dx}, {y, y0, y1, dy} ]
    ]

PolarMap[ func_, {r0_, r1_, dr_}, {p0_, p1_, dp_} ] :=
    Module[ {r, p},
        Picture[ func[r Exp[I p]], {r, r0, r1, dr}, {p, p0, p1, dp} ]
    ]

Picture[ e_, {s_, s0_, s1_, ds_}, {t_, t0_, t1_, dt_} ] :=
    Module[ {hg, vg},
        hg = Curves[ e, {s, s0, s1, ds}, {t, t0, t1} ];
        vg = Curves[ e, {t, t0, t1, dt}, {s, s0, s1} ];
        Show[ Graphics[ Join[hg, vg] ],
              AspectRatio->Automatic, Axes->True ]
    ]

Curves[ xy_, spread_, bounds_ ] :=
    With[{curves = Table[{Re[xy], Im[xy]}, spread]},
        ParametricPlot[curves, bounds, DisplayFunction->Identity][[1]]
    ]

End[ ]

EndPackage[ ]
