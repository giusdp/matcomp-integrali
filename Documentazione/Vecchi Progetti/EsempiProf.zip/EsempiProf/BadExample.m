(* ::Package:: *)

(* :Title: BadExample *)


(* :Context: ProgrammingInMathematica`BadExample` *)

(* :Author: Maeder *)

(* :Summary:
   a function with a local variable that has global scope *)

(* :Package Version  *)
(* :Mathematica Version *)

(* :History:  previous  package versions   *)

(* :Keywords: scope, nesting, bad programming style *)

(* :Sources: biblio  *)

(* :Warnings:
   as the name implies, this is an example of bad programming *)

(* :Discussion: See Section 1.2 of "Programming in Mathematica"*)
(* :Requirements:  other  packages  and/or  Mathematica  version *)

(* This function returns the sum of the first n powers of x *)

(* ATTENZIONE: la  variabile  i  non  e'  dichiarata  locale  *)
PowerSum[x_, n_] := Sum[ x^i, {i, 1, n} ]
