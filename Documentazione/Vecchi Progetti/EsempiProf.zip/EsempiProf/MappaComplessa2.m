(* ::Package:: *)

(* :Title: ComplexMap2bis *)


(* :Context: ProgrammingInMathematica`ComplexMap2` *)

(* :Author: Roman E. Maeder *)

(* :Summary:
   a preliminary version of the ComplexMap package
 *)

(* :Copyright: Maeder *)

(* :Package Version: *)

(* :Mathematica Version:*)

(* :History: *)

(* :Sources:   biblio *)

(* :Limitations:
   this is a preliminary version, for educational purposes only.
   The final code is in ProgrammingInMathematica/ComplexMap.m
*)

(* :Discussion:  *)

BeginPackage["ComplexMap`"]

CartesianMap::usage = "CartesianMap[f, {x0, x1, (dx)}, {y0, y1, (dy)}]
	plots the image of the cartesian coordinate lines under the function f.
	The default values of dx and dy are chosen so that the number of lines
	is equal to the value of the option PlotPoints of Plot[] and Plot3D[ ]."

PolarMap::usage = "PolarMap[f, {r0:0, r1, (dr)}, {p0, p1, (dp)}]
	plots the image of the polar coordinate lines under the function f.
	The default values of dr and dp=dphi are chosen so that the number of lines
	is equal to the value of the option PlotPoints of Plot[] and Plot3D[ ]."

Begin["`Private`"]

(* auxiliary function *)
MakeLines[points_] :=
    Module[ {coords, lines},
        coords = Map[ {Re[#], Im[#]}& , points, {2} ] ;
        lines = Map[ Line, Join[ coords, Transpose[coords] ] ] ;
        Graphics[ lines ]
    ]


(* explicit increments *)
CartesianMap[ func_, {x0_, x1_, dx_}, {y0_, y1_, dy_} ] :=
    Module[ {x, y, coords},
        coords = Table[ N[ func[x + I y] ], {x, x0, x1, dx}, {y, y0, y1, dy} ];
        Show[ MakeLines[coords], AspectRatio -> Automatic, Axes-> Automatic]
    ]


(* default increments *)
CartesianMap[ func_ , {x0_, x1_}, {y0_, y1_} ] :=
    Module[ {dx, dy, plotpoints},
        plotpoints = (* GoldenRatio^8; *) PlotPoints /. Options[Plot];
Print[plotpoints];
        dx=(x1-x0)/(plotpoints-1);
        dy=(y1-y0)/(plotpoints-1);
CartesianMap[ func, {x0, x1, dx}, {y0, y1, dy} ] 
    ]


(* explicit increments *)
PolarMap[ func_, {r0_, r1_, dr_}, {p0_, p1_, dp_} ] :=
    Module[ {r, p, coords},
        coords = Table[ N[ func[r  Exp[I  p] ] ], {r, r0, r1, dr}, {p, p0, p1, dp} ];
        Show[ MakeLines[coords], AspectRatio -> Automatic, Axes-> Automatic]
    ]



(* default increments *)
PolarMap[ func_, {r0_:0, r1_}, {p0_, p1_} ] :=
    Module[ {dr, dp, plotpoints},
        plotpoints = PlotPoints /. Options[Plot];
        dr=(r1-r0)/(plotpoints-1);
        dp=(p1-p0)/(plotpoints-1);
PolarMap[ func, {r0, r1, dr}, {p0, p1, dp} ] 
    ]


End[ ]

EndPackage[ ]
