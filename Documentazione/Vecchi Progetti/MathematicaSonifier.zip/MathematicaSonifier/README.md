﻿# UniversalPlot

## Introduction

Universal Plot is a Wolfram Mathematica package aiming to move function plotting towards the Universal design principles by implementing specific accessibility features and combining them with the more traditional graphical plotting. The following accessibility features are provided:
+ "sonification", or in other words the ability to create a sound that can uniquely describe a given function;"
+ description, or in other words the ability to generate a textual description of the plot of a given function.

While the underlying implementation of these features is pretty complex, one of the main goals of UniversalPlot is to provide users with an easy-to-use tool to take advantage of them without  worrying too much about their complexity.

There are numerous scenarios where this package comes handy. It is proved, for example, that one of the main point of frustration for blind people studying and/or working with STEM subjects is the lack of accessible resources, including graphs and plots.  This package can dramatically help with that, since it can produce accessible representations of them in a completely automated way (i.e. without requiring additional efforts by the user). These representations might come in handy to people with other disabilities too, and perhaps (hopefully) in other scenarios we cannot think of actually! :)


## About sonification

The Sonify[] method produces the sonification of a function. Sonification of a function can be defined as the process of creating a sound that uniquely describes the plot of a given function in a specified range. This can be done by mapping certain properties of the function plot to properties of the generated sound. This topic has been widely discussed in the literature and several approaches to sonify a function have been proposed. The main mappings used within this package are:
+ Sound panning: indicates the point on the x-axis that the function value corresponds to; you can hear the sound moving from left to right; lefmost values sound fragments represent smallest x-axis values;
+ Sound pitch: indicates the y-axis values of the function: the higher the pitch, the higher the represented value is;
+ Additional sounds: certain aspects of the function plot are reflected by introducing specific sounds in the generated sonification. Information represented in this way include the axes-intercepts and the sign of the function. The user needs to become familiar with them in order to fully take advantage of these features, but the learning process is very straightforward.

Important: you are *strongly* advised to use headphones when dealing with sonification, since understanding the conveyed sound becomes much easier.  


## About function description

In addition to sonification, UniversalPlot allows the user to get textual descriptions of function plots. It can produce 3 different kinds of descriptions:
1. "math", ", a description highly focused on the mathematical information reflected by the plot;
2. "visual", a description highly focused on the visual appearance of the function plot;"
3. "standards", a description suited for the state of Georgia performance standards; it can be seen as a kind of description that incorporates the most positive aspects of the previous ones.


## Installation

You can install and use UniversalPlot as any standard Mathematica package. It has been tested under Mathematica 11.0.1, but it should work under any reasonably recent version of Mathematica. Note that UniversalPlot depends on J/Link to work.

You need to copy the UniversalPlot folder in the folder Applications inside the path $UserBaseDirectory.
You’ll need to get the path of your $UserBaseDirectory from within mathematica. Next you can open the project and follow the instrutions.
 



## Credits

This package acts as a wrapper for the
[MathDescriptionEngine (MDE)](https://github.com/benetech/Inactive-Math-Description-Engine)
a java library developed by Nasa as part of the MathTrax project.


##Future development

While the functionalities provided by this package are pretty exciting, of course there is room for further improvements. And if you'd like to work on it you are more than welcome to do that!!!

Here are a few ideas that come to mind:
+ Gamification: some studies have shown that sonification can facilitate studying math concepts for very young students. Thus it could be interesting to develop some sort of game where the user has to guess the characteristics of a function by hearing its sonification; of course the game could be organized so that the difficulty increases over time, "forcing" him/her to learn deeper and deeper how the sonification proces works and the concepts behind it.
+ Better distribution system: it could be great if the package could be compiled into a standalone application, so that it can be executed on different operating systems without requiring Mathematica to be installed.
+ Code cleanup: due to Mathematica's weird behaviors there are several hacks scattered around the code. So if anyone knows how to rework them into more appropriate fixes he/she is more than welcome to do that! ;)
