(* ::Package:: *)

(** This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. 
 *)


(**
* UniversalPlot
* Tries to move function plotting towards the Universal design principles by implementing specific accessibility features, e.g. sonification and text description generation of function plots.
* This package is a wrapper for the MathDescriptionEngine (MDE) java library
https://github.com/benetech/Inactive-Math-Description-Engine
developed by Nasa as part of the MathTrax project.
*)



ClearAll["UniversalPlot`*"];  
BeginPackage[ "UniversalPlot`"]
Sonify::usage = "Sonify[function_, duration_] Creates a sound to describe the given function that lasts duration seconds"
Describe ::usage = "Describe[function_, type_] Produces a textual description of the plot corresponding to the given function"



Begin["`Private`"];
Needs["JLink`"]


(**
* Produces a textual description of the plot corresponding to the given function
* @param function: a string containing the function whose plot has to be described
* @param type: the type of description to produce; can be either "math", "standards" or "visual", defaults to "standards"
* @returns the description
*)
Describe[function_String, type_String: "standards"]:= Module[{settings, solver, describer,description},
InstallJava[];
JavaBlock[
description = "";
settings = JavaNew[MDESettingsClass];
solver = MakeSolver[function];
If[solver@anyDescribable[],
{describer = JavaNew[MDEDescriberClass,solver,settings];
describer@setOutputFormat["text"];
description=describer@getDescriptions[type];
},
{description = "Function not describable"}
];
Return[description];
]
];

(**
*  Creates a sound that uniquely describes a given function in a specific range (sonification)
* @param function: a string containing the function to create the sound for
* @param duration: the duration of the sound to be created, in seconds
* @param xmin: minimum value of the x-axis range to sonify the function in. Defaults to -20
* @param xmax: maximum value of the x-axis range to sonify the function in. Defaults to 20
* @param ymin: minimum value of the y-axis range to sonify the function in. Defaults to 200
* @param ymax: maximum value of the y-axis range to sonify the function in. Defaults to 200
* @param indicateXIntercepts: wether to emit a short sound when the function crosses the x-axis. Note that this might be unperceivable under some circumnstances. Defaults to True
* @param indicateYIntercepts: wether to emit a short sound when the function crosses the y-axis. Note that this might be unperceivab_le under some circumnstances. Defaults to True
*)
Sonify[function_String, duration_Real, xmin_Real: -20.0, xmax_Real: 20.0, ymin_Real: -200.0, ymax_Real: 200.0, indicateXIntercepts_Integer: 1,indicateYIntercepts_Integer: 1] := Module[{settings,solver, sounder},
InstallJava[]
JavaBlock[
settings = JavaNew[MDESettingsClass];
solver = MakeSolver[function, xmin, xmax, ymin, ymax];
If[Not[solver@anySonifiable[]],
	MessageDialog["This function is not sonifiable"],
	sounder=JavaNew[MDESounderClass,solver,settings];
	If[indicateXIntercepts == 1,
	sounder@setUsingChirp[True],
	sounder@setUsingChirp[False]
	];
	If[indicateYIntercepts == 1,
		sounder@setUsingDing[True],
		sounder@setUsingDing[False]
		];
		sounder@sweep[duration];
		sounder@close[];
	]; 
	];
];

(**
* Workaround to fix a bug regarding the incorrect release of sounder object.
* Sometimes the sound get stuck on the last note, so to prevent this, we restart the Java Runtime.
* @param duration: Specify after how much time you should restart the Java Runtime
*)
FixAudio[]:=Module[{},
Pause[1];
ReinstallJava[]
];




(* Symbols defined from now onwards are intended for internal use only, so they're private *)

(* Java library class names *)
MDEDescriberClass = "gov.nasa.ial.mde.describer.Describer"
MDESettingsClass = "gov.nasa.ial.mde.properties.MdeSettings"
MDESolverClass = "gov.nasa.ial.mde.solver.Solver"
MDESounderClass = "gov.nasa.ial.mde.sound.Sounder"




(**
* Initializes a solver with the given parameters. Note that this is an internal object used by the MDE SDK.
* @param function: a string containing the function to create the solver for
* @param xmin: minimumn value of the x-axis to consider. Defaults to -20
* @param xmax: maximum value of the x-axis to consider. Defaults to 20
* @param ymin: minimum value of the y-axis to consider. Defaults to -20
* @param ymax: maximum value of the y-axis to consider. Defaults to 20
* @returns the initialized solver
*)
MakeSolver[function_String, xmin_Real: -20.0, xmax_Real: 20.0, ymin_Real: -20.0, ymax_Real: 20.0] := Module[{solver},
(* Make sure to call this function within a JavaBlock[] and *only* after the Java runtime has been initialized *)
solver=JavaNew[MDESolverClass];
solver@add[function];
solver@solve[xmin,xmax,ymax,ymin];
Return [solver];
];


End[]
EndPackage[]
