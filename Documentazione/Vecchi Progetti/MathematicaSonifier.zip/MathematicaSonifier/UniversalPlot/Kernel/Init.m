(* Mathematica initialization file *)

Get["UniversalPlot`UniversalPlot`"]
