(* ::Package:: *)

(*
	Copyright (C) 2015 Giulio Biagini, Orgest Shehaj

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	Giulio Biagini - giulio.biagini@studio.unibo.it
	Orgest Shehaj - orgest.shehaj@studio.unibo.it
*)




BeginPackage["Idrologia`"];

(* MODEL *)

ReadData::usage="\!\(\*
StyleBox[\"ReadData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"path\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di importare il file specificato dal parametro
passato in input e leggerne i dati.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"path\",\nFontSlant->\"Italic\"]\) - specifica il percorso del file dal quale leggere i dati
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i dati grezzi presenti nel file
";
ReadData[path_]:=Module[{xlsxFile},
	(* import the file *)
	xlsxFile=Import[path];
	(* read the file content *)
	xlsxFile[[1]]
]

CleanData::usage="\!\(\*
StyleBox[\"CleanData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"rawData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di 'pulire' i dati in ingresso eliminando le
prime due righe di intestazione e la prima colonna dei dati delle
mezz'ore, non richieste dal modello.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"rawData\",\nFontSlant->\"Italic\"]\) - i dati grezzi da 'pulire'
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i soli dati utili al programma
";
CleanData[rawData_]:=Module[{rawDataRows, rawDataColumns, cleanDataStartingRow, cleanDataEndingRow, cleanDataStartingColumn, cleanDataEndingColumn},
	(* raw data size *)
	rawDataRows=Length[rawData];
	rawDataColumns=6;
	(* ignores the first and the second row (table header) *)
	cleanDataStartingRow=3;
	cleanDataEndingRow=rawDataRows;
	(* ignores the first column (data from the first 1/2 hour) *)
	cleanDataStartingColumn=2;
	cleanDataEndingColumn=rawDataColumns;
	(* cut the data *)
	Table[
		rawData[[i,j]],
		{i,cleanDataStartingRow,cleanDataEndingRow},
		{j,cleanDataStartingColumn,cleanDataEndingColumn}
	]
]

OrderData::usage="\!\(\*
StyleBox[\"OrderData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"cleanedData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di ordinare i dati dall'evento pi\[UGrave] piovoso a
quello meno piovoso; l'ordinamento \[EGrave] fatto a partire dall'ultima
colonna, ovvero dalla quantit\[AGrave] di acqua caduta nelle 24 ore,
procedendo, nel caso in cui i dati di pi\[UGrave] eventi siano uguali, con il
confronto delle rimanenti colonne, partendo dalla quarta fino (se
necessario) alla prima.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"cleanedData\",\nFontSlant->\"Italic\"]\) - i dati gi\[AGrave] 'puliti' letti dal file in input
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i dati ordinati partendo dall'evento pi\[UGrave] piovoso
";
OrderData[cleanedData_]:=Module[{inverseOrderedData},
	(* order the data *)
	inverseOrderedData=SortBy[cleanedData,{#[[5]],#[[4]],#[[3]],#[[2]],#[[1]]}&];
	Reverse[inverseOrderedData]
]

GetEmpiricalProbabilities::usage="\!\(\*
StyleBox[\"GetEmpiricalProbabilities\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"orderedData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di calcolare le probabilit\[AGrave] empiriche degli
eventi passati in input.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"orderedData\",\nFontSlant->\"Italic\"]\) - gli eventi di cui si vogliono calcolare le
probabilit\[AGrave] empiriche
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - le probabilit\[AGrave] empiriche degli eventi in ingresso
";
GetEmpiricalProbabilities[orderedData_]:=Module[{},
	(* calculate the empirical probabilities *)
	(Range[Length[orderedData]]/(1+Length[orderedData]))//N
]

GetReturnTimes::usage="\!\(\*
StyleBox[\"GetReturnTimes\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"empiricalProbabilities\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di calcolare i tempi di ritorno delle
probabilit\[AGrave] empiriche passate in input associate ai relativi eventi.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"empiricalProbabilities\",\nFontSlant->\"Italic\"]\) - le probabilit\[AGrave] empiriche degli
eventi di cui si vogliono calcolare i tempi di ritorno
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i tempi di ritorno degli eventi
";
GetReturnTimes[empiricalProbabilities_]:=Module[{},
	(* calculate the return times *)
	(1/(1-empiricalProbabilities))//N
]

GetDangerValues::usage="\!\(\*
StyleBox[\"GetDangerValues\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"returnTimes\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di calcolare i valori di rischio dei tempi
di ritorno passati in input associati ai relativi eventi.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"returnTimes\",\nFontSlant->\"Italic\"]\) - i tempi di ritorno degli eventi
di cui si vogliono calcolare i valori di rischio
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i valori di rischio degli eventi
";
GetDangerValues[returnTimes_]:=Module[{},
	(* calculate the danger values *)
	(1/returnTimes)//N
]

GetLSPPParameters::usage="\!\(\*
StyleBox[\"GetLSPPParameters\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"orderedData\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\)
Funzione che si occupa di calcolare i parametri 'a' ed 'n' delle LSPP.
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"parameter\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\" \",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"orderedData\",\nFontSlant->\"Italic\"]\) - gli eventi di cui si vogliono calcolare i
parametri delle equazioni che approssimano le relative LSPP
\!\(\*
StyleBox[\"@\",\nFontSlant->\"Italic\"]\)\!\(\*
StyleBox[\"output\",\nFontSlant->\"Italic\"]\) - i parametri 'a' ed 'n' delle equazioni
";
GetLSPPParameters[orderedData_]:=Module[{orderedDataRows},
	orderedDataRows=Length[orderedData];
	(* calculate the 'a' and 'n' parameters *)
	Table[
		FindFit[orderedData[[i]],a*t^n,{a,n},t],
		{i,1,orderedDataRows}
	]
]

(* VIEW *)

view=DynamicModule[{
		path="",
		rawData="",
		cleanedData="",
		orderedData="",
		empiricalProbabilities="",
		returnTimes="",
		dangerValues="",
		lsppParameters=""
	},
	
	(* title *)
	
	viewTitle="IDF - Intensity Duration Frequency";
	
	(* input *)
	
	labelPath=Dynamic[Style["Choose the path of the file:",If[StringQ[path]&&StringLength[path]>0&&FileExistsQ[path],Black,Red]]];
	
	textFieldPath=InputField[Dynamic[path], String];
	
	buttonBrowsePath=FileNameSetter[Dynamic[path]];
	
	(* execution *)
	
	buttonLoadData=Button["Load data", Function[
		rawData=ReadData[path];
		cleanedData=CleanData[rawData];
		orderedData=OrderData[cleanedData];
		empiricalProbabilities=GetEmpiricalProbabilities[orderedData];
		returnTimes=GetReturnTimes[empiricalProbabilities];
		dangerValues=GetDangerValues[returnTimes];
		lsppParameters=GetLSPPParameters[orderedData];
	]];
	
	(* show all data *)
	
	buttonPrintAll=Button["Print all data", Function[
		Print["Event Number -> Ordered Data -> Empirical Probabilities -> Return Times -> Danger Values -> LSPP Parameters"]
		Print[TableForm[Table[{
				StringJoin["Event ",ToString[i]],
				ToString[orderedData[[i]]],
				ToString[empiricalProbabilities[[i]]],
				ToString[returnTimes[[i]]],
				ToString[dangerValues[[i]]],
				ToString[lsppParameters[[i]]]
			},
			{i,1,Length[orderedData]}]
		]]
	]];
	
	buttonPlotLSPP=Manipulate[
		Dynamic[Plot[(Part[lsppParameters[[event]][[1]],2])*d^(Part[lsppParameters[[event]][[2]],2]),{d,0,24},PlotStyle->{PointSize[0.03]},AxesLabel->{\[ScriptCapitalD],\[ScriptCapitalH]}]],
		{event,1,Dynamic[Length[lsppParameters]],1}
	];
	
	(* show the raw/cleaned data *)
	
	labelData=Style["Show data:"];
	
	buttonPrintRawData=Button["Print raw data", Function[
		Print["RAW DATA:"]
		Print[TableForm[rawData]]
	]];
	
	buttonPrintCleanedData=Button["Print cleaned data", Function[
		Print["CLEANED DATA:"]
		Print[TableForm[cleanedData]]
	]];
	
	buttonPrintOrderedData=Button["Print ordered data", Function[
		Print["ORDERED DATA:"]
		Print[TableForm[orderedData]]
	]];
	
	(* show the values associated to the return times *)
	
	labelReturnTimes=Style["Return times:"];
	
	buttonPrintEmpiricalProbabilities=Button["Print empirical probabilities", Function[
		Print["EMPIRICAL PROBABILITIES:"]
		Print[TableForm[empiricalProbabilities]]
	]];
	
	buttonPrintReturnTimes=Button["Print return times", Function[
		Print["RETURN TIMES:"]
		Print[TableForm[returnTimes]]
	]];
	
	buttonPrintDangerValues=Button["Print danger values", Function[
		Print["DANGER VALUES:"]
		Print[TableForm[dangerValues]]
	]];
	
	(* show the data associated to the LSPP *)
	
	labelLSPP=Style["LSPP:"];
	
	buttonPrintLSPPParameters=Button["Print LSPP 'a' and 'n' parameters", Function[
		Print["LSPP PARAMETERS:"]
		Print[TableForm[lsppParameters]]
	]];
	
	(* deploy the first view *)
	
	Deploy[
		Panel[
			Grid[{
				(* a panel with the input field *)
				{Panel[
					Grid[{
						{labelPath},
						{textFieldPath,buttonBrowsePath}
					},Alignment->Center]
				]},
				(* a button which allows to load and compute the data *)
				{buttonLoadData},
				(* a button which allows to show all the computed data *)
				{Style[""]},
				{buttonPrintAll},
				{buttonPlotLSPP},
				(* this section contains the button to show the data *)
				{Style[""]},
				{labelData},
				{buttonPrintRawData},
				{buttonPrintCleanedData},
				{buttonPrintOrderedData},
				(* all the buttons to show the return times values *)
				{Style[""]},
				{labelReturnTimes},
				{buttonPrintEmpiricalProbabilities},
				{buttonPrintReturnTimes},
				{buttonPrintDangerValues},
				(* buttons dealing with the LSPP *)
				{Style[""]},
				{labelLSPP},
				{buttonPrintLSPPParameters}
			},Alignment->Center],
			viewTitle,
			Alignment->Center
		]
	]
]

EndPackage[]
